import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final String CFG = "config";
final String DEFAULT_TEXT = "晚上好，今晚的月亮很圆。";
final int DEFAULT_DURATION = 3000;

int pdp(Context c, float dp) {
    if (c == null || c.getResources() == null) return (int) (dp * 2 + 0.5f);
    return (int) (dp * c.getResources().getDisplayMetrics().density + 0.5f);
}

GradientDrawable pRound(int color, int radiusDp, Context c) {
    GradientDrawable gd = new GradientDrawable();
    gd.setColor(color);
    gd.setCornerRadius(pdp(c, radiusDp));
    return gd;
}

int popupDuration() {
    try {
        String d = getString(CFG, "duration", String.valueOf(DEFAULT_DURATION));
        if (d != null && d.trim().length() > 0) {
            int v = Integer.parseInt(d.trim());
            if (v < 0) return 0;
            if (v > 0 && v < 500) return 500;
            return v;
        }
    } catch (Throwable ignored) { }
    return DEFAULT_DURATION;
}

void showOneLinePopup(final Context ctx) {
    String text = getString(CFG, "text", DEFAULT_TEXT);
    if (text == null || text.trim().length() == 0) text = DEFAULT_TEXT;

    final Dialog dialog = new Dialog(ctx);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout box = new LinearLayout(ctx);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setBackground(pRound(Color.WHITE, 20, ctx));
    box.setPadding(pdp(ctx, 22), pdp(ctx, 24), pdp(ctx, 22), pdp(ctx, 16));

    TextView tv = new TextView(ctx);
    tv.setText(text);
    tv.setTextSize(17);
    tv.setTextColor(Color.parseColor("#1C1B1F"));
    tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    tv.setGravity(android.view.Gravity.CENTER);
    tv.setLineSpacing(pdp(ctx, 4), 1f);
    box.addView(tv);

    Button ok = new Button(ctx);
    ok.setText("好");
    ok.setTextSize(15);
    ok.setTextColor(Color.WHITE);
    ok.setBackground(pRound(Color.parseColor("#3B71FE"), 20, ctx));
    ok.setStateListAnimator(null);
    ok.setElevation(0);
    LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, pdp(ctx, 44));
    olp.topMargin = pdp(ctx, 18);
    box.addView(ok, olp);

    ScrollView sv = new ScrollView(ctx);
    sv.setVerticalScrollBarEnabled(false);
    sv.addView(box);

    dialog.setContentView(sv);
    dialog.setCanceledOnTouchOutside(true);

    Window win = dialog.getWindow();
    if (win != null) {
        win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        win.setDimAmount(0f);
    }

    final Handler handler = new Handler(Looper.getMainLooper());
    final View decor = win == null ? null : win.getDecorView();

    final Runnable fadeOut = new Runnable() {
        public void run() {
            try {
                if (decor != null) {
                    decor.animate().alpha(0f).setDuration(220)
                            .setInterpolator(new DecelerateInterpolator()).start();
                }
            } catch (Throwable ignored) { }
            handler.postDelayed(new Runnable() {
                public void run() {
                    try {
                        if (dialog.isShowing()) dialog.dismiss();
                    } catch (Throwable ignored) { }
                }
            }, 240);
        }
    };

    dialog.show();
    if (win != null) {
        win.setLayout(pdp(ctx, 280), ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    try {
        if (decor != null) {
            decor.setAlpha(0f);
            decor.animate().alpha(1f).setDuration(180).start();
        }
    } catch (Throwable ignored) { }

    int dur = popupDuration();
    if (dur > 0) handler.postDelayed(fadeOut, dur);

    ok.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            try {
                handler.removeCallbacks(fadeOut);
            } catch (Throwable ignored) { }
            fadeOut.run();
        }
    });
}

void showTextEditor(final Context ctx) {
    final Dialog dialog = new Dialog(ctx);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout box = new LinearLayout(ctx);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setBackground(pRound(Color.WHITE, 20, ctx));
    box.setPadding(pdp(ctx, 22), pdp(ctx, 22), pdp(ctx, 22), pdp(ctx, 18));

    TextView title = new TextView(ctx);
    title.setText("弹窗设置");
    title.setTextSize(17);
    title.setTextColor(Color.parseColor("#1C1B1F"));
    title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    box.addView(title);

    final EditText et = new EditText(ctx);
    et.setText(getString(CFG, "text", DEFAULT_TEXT));
    et.setHint("想弹出来的那句话");
    et.setTextSize(15);
    et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
    et.setBackground(pRound(Color.parseColor("#F5F7FA"), 12, ctx));
    et.setPadding(pdp(ctx, 14), pdp(ctx, 12), pdp(ctx, 14), pdp(ctx, 12));
    LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    elp.topMargin = pdp(ctx, 12);
    box.addView(et, elp);

    TextView lab = new TextView(ctx);
    lab.setText("停留时长（毫秒，0 = 不自动消失）");
    lab.setTextSize(13);
    lab.setTextColor(Color.parseColor("#49454F"));
    lab.setPadding(0, pdp(ctx, 14), 0, pdp(ctx, 4));
    box.addView(lab);

    final EditText etDur = new EditText(ctx);
    etDur.setText(String.valueOf(popupDuration()));
    etDur.setInputType(InputType.TYPE_CLASS_NUMBER);
    etDur.setTextSize(15);
    etDur.setBackground(pRound(Color.parseColor("#F5F7FA"), 12, ctx));
    etDur.setPadding(pdp(ctx, 14), pdp(ctx, 12), pdp(ctx, 14), pdp(ctx, 12));
    box.addView(etDur);

    Button save = new Button(ctx);
    save.setText("保存并试一下");
    save.setTextSize(15);
    save.setTextColor(Color.WHITE);
    save.setBackground(pRound(Color.parseColor("#3B71FE"), 20, ctx));
    save.setStateListAnimator(null);
    LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, pdp(ctx, 44));
    slp.topMargin = pdp(ctx, 16);
    box.addView(save, slp);

    save.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String t = et.getText().toString().trim();
            if (t.length() == 0) {
                qqToast(0, "文案不能为空");
                return;
            }
            String ds = etDur.getText().toString().trim();
            int dur = DEFAULT_DURATION;
            try {
                if (ds.length() > 0) dur = Integer.parseInt(ds);
            } catch (Throwable ignored) { }
            if (dur < 0) dur = 0;
            putString(CFG, "text", t);
            putString(CFG, "duration", String.valueOf(dur));
            try {
                if (dialog.isShowing()) dialog.dismiss();
            } catch (Throwable ignored) { }
            qqToast(2, "已保存");
            try {
                showOneLinePopup(ctx);
            } catch (Throwable ignored) { }
        }
    });

    dialog.setContentView(box);
    dialog.setCanceledOnTouchOutside(true);
    Window win = dialog.getWindow();
    if (win != null) {
        win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        win.setDimAmount(0.45f);
    }
    dialog.show();
    if (win != null) {
        win.setLayout(pdp(ctx, 300), ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}

void popupRun(final boolean editor) {
    final Activity act = getNowActivity();
    if (act == null) {
        qqToast(1, "没拿到当前界面");
        return;
    }
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (editor) showTextEditor(act);
                else showOneLinePopup(act);
            } catch (Throwable t) {
                qqToast(1, "弹窗失败: " + t.toString());
            }
        }
    });
}

addItem("弹一句话", "onPopupMenu");
void onPopupMenu(int chatType, String peerUin, String peerName) {
    popupRun(false);
}

addItem("弹窗设置", "onPopupSettings");
void onPopupSettings(int chatType, String peerUin, String peerName) {
    popupRun(true);
}
