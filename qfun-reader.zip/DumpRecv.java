public interface DumpRecv {

    void onReceive(byte[] data);

}