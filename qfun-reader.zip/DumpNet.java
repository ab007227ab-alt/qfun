import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.zip.GZIPOutputStream;

import android.os.Bundle;

import com.tencent.qphone.base.remote.FromServiceMsg;
import com.tencent.qphone.base.remote.ToServiceMsg;
import mqq.app.NewIntent;
import mqq.app.api.impl.SSOEasyServlet;
import mqq.observer.BusinessObserver;

import me.yxp.qfun.utils.qq.QQCurrentEnv;

loadJava(pluginPath + "/DumpRecv.java");

public class DumpNet {

    public static byte[] compressGzip(byte[] data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            GZIPOutputStream gos = new GZIPOutputStream(bos);
            gos.write(data);
            gos.close();
        } catch (Exception ignored) { }
        return bos.toByteArray();
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xFF & b);
            if (hex.length() == 1) sb.append('0');
            sb.append(hex);
        }
        return sb.toString();
    }
    
    public static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }

    public static byte[] packet(byte[] data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(bos);
        try {
            dos.writeInt(data.length + 4);
            dos.write(data);
        } catch (Exception ignored) { }
        return bos.toByteArray();
    }

    public static void sendRequest(String serviceCmd, byte[] rawData, DumpRecv receiver) {
        byte[] reqBytes = packet(rawData);
        NewIntent intent = new NewIntent(context, SSOEasyServlet.class);
        ToServiceMsg toServiceMsg = new ToServiceMsg("mobileqq.service", myUin, serviceCmd);
        toServiceMsg.wupBuffer = reqBytes;
        
        intent.setObserver((type, isSuccess, bundle) -> {
            if (isSuccess && bundle != null) {
                FromServiceMsg fromMsg = bundle.getParcelable("FromServiceMsg");
                if (fromMsg != null) {
                    receiver.onReceive(fromMsg.wupBuffer);
                } else {
                    receiver.onReceive(null);
                }
            } else {
                receiver.onReceive(null);
            }
        });
        
        intent.putExtra("ToServiceMsg", toServiceMsg);
        QQCurrentEnv.INSTANCE.getQQAppInterface().startServlet(intent);
    }
}