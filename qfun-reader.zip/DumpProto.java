import org.json.JSONArray;
import org.json.JSONObject;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DumpProto {

    public HashMap<Integer, Object> values = new HashMap<>(8);

    public void fromBytes(byte[] b) {
        if (b == null || b.length == 0) return;

        int offset = 0;
        int length = b.length;

        // 跳过 4 字节的 SSO 包头
        if (length >= 4 && (b[0] & 0xFF) == 0 && (b[1] & 0xFF) == 0) {
            offset = 4;
            length -= 4;
        }

        tryParseFromBytes(b, offset, length);
    }

    public boolean tryParseFromBytes(byte[] b, int offset, int length) {
        if (length <= 0) return false;

        try {
            CodedInputStream in = CodedInputStream.newInstance(b, offset, length);

            while (in.getBytesUntilLimit() > 0) {
                int tag = in.readTag();
                if (tag == 0) break;

                int wireType = tag & 7;
                if (wireType == 3 || wireType == 4 || wireType > 5) {
                    return false;
                }

                int fieldNumber = tag >>> 3;
                if (fieldNumber == 0) return false;

                switch (wireType) {
                    case 0:
                        putValue(fieldNumber, in.readInt64());
                        break;
                    case 1:
                        putValue(fieldNumber, in.readRawVarint64());
                        break;
                    case 5:
                        putValue(fieldNumber, in.readFixed32());
                        break;
                    case 2:
                        byte[] subBytes = in.readByteArray();
                        boolean processed = false;

                        // 优先尝试子消息反序列化
                        if (looksLikeProto(subBytes)) {
                            DumpProto subData = new DumpProto();
                            if (subData.tryParseFromBytes(subBytes, 0, subBytes.length) && !subData.values.isEmpty()) {
                                putValue(fieldNumber, subData);
                                processed = true;
                            }
                        }

                        // 子消息校验不通过时，按严格 UTF-8 文本解析
                        if (!processed && isStrictUtf8(subBytes)) {
                            putValue(fieldNumber, new String(subBytes, StandardCharsets.UTF_8));
                            processed = true;
                        }

                        // 兜底作为十六进制字符串存储
                        if (!processed) {
                            putValue(fieldNumber, "hex->" + bytesToHex(subBytes));
                        }
                        break;
                    default:
                        return false;
                }
            }
            return true;
        } catch (Exception e) {
            values.clear();
            return false;
        }
    }

    private void putValue(int key, Object value) {
        Object current = values.get(key);
        if (current == null) {
            values.put(key, value);
        } else if (current instanceof List) {
            ((List<Object>) current).add(value);
        } else {
            List<Object> list = new ArrayList<>(4);
            list.add(current);
            list.add(value);
            values.put(key, list);
        }
    }

    private boolean looksLikeProto(byte[] b) {
        if (b.length == 0) return false;
        int tag = b[0] & 0xFF;
        int wire = tag & 7;
        int field = tag >>> 3;
        return field != 0 && wire != 3 && wire != 4 && wire <= 5;
    }

    private boolean isStrictUtf8(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return true;
        int i = 0, len = bytes.length;
        while (i < len) {
            int b = bytes[i] & 0xFF;
            if (b < 0x80) {
                i++;
            } else if (b < 0xC2 || b > 0xF4) {
                return false;
            } else if (b < 0xE0) {
                if (i + 1 >= len || (bytes[i + 1] & 0xC0) != 0x80) return false;
                i += 2;
            } else if (b < 0xF0) {
                if (i + 2 >= len || (bytes[i + 1] & 0xC0) != 0x80 || (bytes[i + 2] & 0xC0) != 0x80) return false;
                if (b == 0xE0 && (bytes[i + 1] & 0xFF) < 0xA0) return false;
                i += 3;
            } else {
                if (i + 3 >= len || (bytes[i + 1] & 0xC0) != 0x80 || (bytes[i + 2] & 0xC0) != 0x80 || (bytes[i + 3] & 0xC0) != 0x80) return false;
                if (b == 0xF0 && (bytes[i + 1] & 0xFF) < 0x90) return false;
                i += 4;
            }
        }
        return true;
    }

    public void fromJSON(JSONObject json) {
        try {
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) {
                String keyStr = keys.next();
                int key = Integer.parseInt(keyStr);
                Object value = json.get(keyStr);

                if (value instanceof JSONObject) {
                    DumpProto subData = new DumpProto();
                    subData.fromJSON((JSONObject) value);
                    putValue(key, subData);
                } else if (value instanceof JSONArray) {
                    JSONArray arr = (JSONArray) value;
                    for (int i = 0; i < arr.length(); i++) {
                        Object arrItem = arr.get(i);
                        if (arrItem instanceof JSONObject) {
                            DumpProto subData = new DumpProto();
                            subData.fromJSON((JSONObject) arrItem);
                            putValue(key, subData);
                        } else {
                            putValue(key, arrItem);
                        }
                    }
                } else {
                    putValue(key, value);
                }
            }
        } catch (Exception ignored) { }
    }

    public JSONObject toJSON() throws Exception {
        JSONObject obj = new JSONObject();
        for (Map.Entry<Integer, Object> entry : values.entrySet()) {
            Integer kIndex = entry.getKey();
            Object val = entry.getValue();

            if (val instanceof List) {
                JSONArray arr = new JSONArray();
                for (Object o : (List<?>) val) {
                    arr.put(valueToText(o));
                }
                obj.put(String.valueOf(kIndex), arr);
            } else {
                obj.put(String.valueOf(kIndex), valueToText(val));
            }
        }
        return obj;
    }

    private Object valueToText(Object value) throws Exception {
        if (value instanceof DumpProto) {
            return ((DumpProto) value).toJSON();
        }
        return value;
    }

    public byte[] toBytes() {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        CodedOutputStream out = CodedOutputStream.newInstance(bos);
        try {
            for (Map.Entry<Integer, Object> entry : values.entrySet()) {
                int key = entry.getKey();
                Object val = entry.getValue();

                if (val instanceof List) {
                    for (Object o : (List<?>) val) {
                        writeField(out, key, o);
                    }
                } else {
                    writeField(out, key, val);
                }
            }
            out.flush();
            return bos.toByteArray();
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private void writeField(CodedOutputStream out, int index, Object o) throws Exception {
        if (o instanceof Long) {
            out.writeInt64(index, (Long) o);
        } else if (o instanceof Integer) {
            out.writeInt32(index, (Integer) o);
        } else if (o instanceof DumpProto) {
            out.writeByteArray(index, ((DumpProto) o).toBytes());
        } else if (o instanceof String) {
            String s = (String) o;
            if (s.startsWith("hex->")) {
                out.writeByteArray(index, hexToBytes(s.substring(5)));
            } else {
                out.writeByteArray(index, s.getBytes(StandardCharsets.UTF_8));
            }
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b & 0xFF));
        }
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}