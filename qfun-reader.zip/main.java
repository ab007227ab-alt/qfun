import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

loadJava(pluginPath + "/DumpRecv.java");
loadJava(pluginPath + "/DumpProto.java");
loadJava(pluginPath + "/DumpNet.java");

void dlog(String s) {
    try {
        java.io.FileWriter fw = new java.io.FileWriter(pluginPath + "/log.txt", true);
        fw.write(new java.text.SimpleDateFormat("MM-dd HH:mm:ss")
                .format(new java.util.Date()) + "  " + s + "\n");
        fw.close();
    } catch (Throwable ignored) { }
}

int ddp(Context c, float dp) {
    if (c == null || c.getResources() == null) return (int) (dp * 2 + 0.5f);
    return (int) (dp * c.getResources().getDisplayMetrics().density + 0.5f);
}

GradientDrawable dRound(int color, int r, Context c) {
    GradientDrawable g = new GradientDrawable();
    g.setColor(color);
    g.setCornerRadius(ddp(c, r));
    return g;
}

String dumpClientVer() {
    try {
        String v = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
        if (v != null && v.length() > 0) return "android " + v;
    } catch (Throwable ignored) { }
    return "";
}

String dumpPretty(JSONObject body) {
    if (body == null) return "没有返回数据";
    StringBuilder sb = new StringBuilder();
    try {
        Object o = body.opt("1");
        JSONArray arr = new JSONArray();
        if (o instanceof JSONArray) arr = (JSONArray) o;
        else if (o instanceof JSONObject) arr.put(o);

        sb.append("条目数: ").append(arr.length()).append("\n\n");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject it = arr.optJSONObject(i);
            if (it == null) continue;
            sb.append("#").append(i + 1).append(" ").append(it.optString("4")).append("\n");
            sb.append("appId: ").append(it.optString("1")).append("\n");
            sb.append("type : ").append(it.optString("3")).append("\n");
            sb.append("icon : ").append(it.optString("5")).append("\n");
            sb.append("desc : ").append(it.optString("6")).append("\n");
            sb.append("jump : ").append(it.optString("7")).append("\n");
            sb.append("----\n");
        }
    } catch (Throwable t) {
        sb.append("解析失败: ").append(t.toString());
    }
    return sb.toString();
}


String gFormText = "";

String dumpForm(JSONObject body) {
    if (body == null) return "";
    StringBuilder sb = new StringBuilder();
    try {
        Object o = body.opt("1");
        JSONArray arr = new JSONArray();
        if (o instanceof JSONArray) arr = (JSONArray) o;
        else if (o instanceof JSONObject) arr.put(o);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject it = arr.optJSONObject(i);
            if (it == null) continue;
            sb.append("按钮名称: ").append(it.optString("4")).append("\n");
            sb.append("图标链接: ").append(it.optString("5")).append("\n");
            sb.append("跳转链接: ").append(it.optString("7")).append("\n");
            sb.append("AppID  : ").append(it.optString("1")).append("\n");
            sb.append("--------\n");
        }
    } catch (Throwable t) { }
    return sb.toString();
}

void dumpShow(final Activity act, final String text) {
    final Dialog dialog = new Dialog(act);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout box = new LinearLayout(act);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setBackground(dRound(Color.WHITE, 18, act));
    box.setPadding(ddp(act, 18), ddp(act, 18), ddp(act, 18), ddp(act, 14));

    TextView title = new TextView(act);
    title.setText("群快捷栏原始数据");
    title.setTextSize(16);
    title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    title.setTextColor(Color.parseColor("#1C1B1F"));
    box.addView(title);

    ScrollView sv = new ScrollView(act);
    TextView tv = new TextView(act);
    tv.setText(text);
    tv.setTextSize(12);
    tv.setTextIsSelectable(true);
    tv.setTypeface(Typeface.MONOSPACE);
    tv.setTextColor(Color.parseColor("#1C1B1F"));
    sv.addView(tv);
    LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ddp(act, 360));
    slp.topMargin = ddp(act, 10);
    box.addView(sv, slp);

    Button copy = new Button(act);
    copy.setText("复制全部");
    copy.setTextSize(14);
    copy.setTextColor(Color.WHITE);
    copy.setBackground(dRound(Color.parseColor("#3B71FE"), 18, act));
    copy.setStateListAnimator(null);
    LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ddp(act, 42));
    clp.topMargin = ddp(act, 12);
    box.addView(copy, clp);

    copy.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            try {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("shortcut", text));
                qqToast(2, "已复制");
            } catch (Throwable t) {
                qqToast(1, "复制失败");
            }
        }
    });

    Button copyForm = new Button(act);
    copyForm.setText("复制填表格式");
    copyForm.setTextSize(14);
    copyForm.setTextColor(Color.WHITE);
    copyForm.setBackground(dRound(Color.parseColor("#22C55E"), 18, act));
    copyForm.setStateListAnimator(null);
    LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ddp(act, 42));
    flp.topMargin = ddp(act, 8);
    box.addView(copyForm, flp);

    copyForm.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            try {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("shortcut-form", gFormText));
                qqToast(2, "已复制填表格式");
            } catch (Throwable t) {
                qqToast(1, "复制失败");
            }
        }
    });

    Button close = new Button(act);
    close.setText("关闭");
    close.setTextSize(14);
    close.setTextColor(Color.parseColor("#3B71FE"));
    close.setBackground(dRound(Color.parseColor("#EEF2FF"), 18, act));
    close.setStateListAnimator(null);
    LinearLayout.LayoutParams xlp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ddp(act, 42));
    xlp.topMargin = ddp(act, 8);
    box.addView(close, xlp);

    close.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            try {
                if (dialog.isShowing()) dialog.dismiss();
            } catch (Throwable ignored) { }
        }
    });

    dialog.setContentView(box);
    dialog.setCanceledOnTouchOutside(true);
    Window win = dialog.getWindow();
    if (win != null) {
        win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        win.setDimAmount(0.45f);
    }
    dialog.show();
    if (win != null) {
        win.setLayout(ddp(act, 330), ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}

void dumpQuery(String peer) {
    dlog("menu clicked, peer=" + peer);
    try {
        String digits = peer == null ? "" : peer.replaceAll("[^0-9]", "");
        if (digits.length() == 0) {
            qqToast(0, "请在群聊里点这个菜单");
            return;
        }
        long groupCode = Long.parseLong(digits);

        JSONObject body = new JSONObject();
        body.put("1", groupCode);
        body.put("2", 30003);
        body.put("3", 2);

        JSONObject req = new JSONObject();
        req.put("1", 38665);
        req.put("2", 0);
        req.put("3", 0);
        req.put("4", body);
        req.put("6", dumpClientVer());

        DumpProto proto = new DumpProto();
        proto.fromJSON(req);

        dlog("sending 0x9709 for " + groupCode);
        qqToast(2, "查询中…");

        DumpNet.sendRequest("OidbSvcTrpcTcp.0x9709_0", proto.toBytes(), new DumpRecv() {
            public void onReceive(byte[] data) {
                String out;
                if (data == null) {
                    out = "查询失败（返回为空）";
                } else {
                    try {
                        DumpProto rp = new DumpProto();
                        rp.fromBytes(data);
                        JSONObject body4 = rp.toJSON().optJSONObject("4");
                        out = dumpPretty(body4);
                        gFormText = dumpForm(body4);
                    } catch (Throwable t) {
                        out = "解析失败: " + t.toString();
                    }
                }
                dlog("parsed, len=" + out.length());
                dumpShowSafe(out);
            }
        });

    } catch (Throwable t) {
        dlog("query error: " + t);
        qqToast(1, "失败: " + t.toString());
    }
}

void dumpShowSafe(final String text) {
    try {
        final Activity act = getNowActivity();
        if (act == null) {
            dlog("no activity");
            return;
        }
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    dumpShow(act, text);
                } catch (Throwable t) {
                    dlog("show error: " + t);
                    qqToast(1, "显示失败");
                }
            }
        });
    } catch (Throwable t) {
        dlog("showSafe error: " + t);
    }
}

addItem("读取群快捷栏", "onDumpMenu");

void onDumpMenu(int chatType, String peerUin, String peerName) {
    dumpQuery(peerUin);
}

dlog("plugin loaded");
