import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

final String CFG = "token";
final String DEFAULT_KEY = "60b1bbddc1e59ff0a911fb6cbb9dd0d2";

int hdp(Context c, float dp) {
    if (c == null || c.getResources() == null) return (int) (dp * 2 + 0.5f);
    return (int) (dp * c.getResources().getDisplayMetrics().density + 0.5f);
}

GradientDrawable hRound(int color, int r, Context c) {
    GradientDrawable g = new GradientDrawable();
    g.setColor(color);
    g.setCornerRadius(hdp(c, r));
    return g;
}

String apiKey() {
    String k = getString(CFG, "key", DEFAULT_KEY);
    if (k == null || k.trim().length() == 0) return DEFAULT_KEY;
    return k.trim();
}

void hCopy(Context ctx, String s) {
    try {
        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("url", s));
    } catch (Throwable ignored) { }
}

/** 压缩到 max 边以内，返回 base64（无换行） */
String shrinkToBase64(String path, int max) {
    try {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, o);
        if (o.outWidth <= 0) return null;

        int sample = 1;
        while (o.outWidth / sample > max || o.outHeight / sample > max) sample *= 2;

        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap bmp = BitmapFactory.decodeFile(path, o2);
        if (bmp == null) return null;

        int w = bmp.getWidth(), h = bmp.getHeight();
        if (w > max || h > max) {
            float scale = max / (float) Math.max(w, h);
            Bitmap nb = Bitmap.createScaledBitmap(bmp, Math.max(1, (int) (w * scale)),
                    Math.max(1, (int) (h * scale)), true);
            if (nb != bmp) bmp = nb;
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
        byte[] data = bos.toByteArray();
        if (data.length > 2 * 1024 * 1024) {
            bos.reset();
            bmp.compress(Bitmap.CompressFormat.JPEG, 88, bos);
            data = bos.toByteArray();
        }
        return Base64.encodeToString(data, Base64.NO_WRAP);
    } catch (Throwable t) {
        return null;
    }
}

String uploadBase64(String key, String b64) {
    HttpURLConnection conn = null;
    try {
        URL url = new URL("https://api.imgbb.com/1/upload");
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        String body = "key=" + URLEncoder.encode(key, "UTF-8")
                + "&expiration=0"
                + "&image=" + URLEncoder.encode(b64, "UTF-8");

        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();

        String resp = new String(bo.toByteArray(), "UTF-8");
        if (code != 200) return "ERR " + code + " " + resp;

        JSONObject j = new JSONObject(resp);
        JSONObject d = j.optJSONObject("data");
        if (d == null) return "ERR no data: " + resp;
        String u = d.optString("display_url");
        if (u == null || u.length() == 0) u = d.optString("url");
        return u;
    } catch (Throwable t) {
        return "ERR " + t.toString();
    } finally {
        try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) { }
    }
}


String uploadToProxy(String endpoint, String b64) {
    HttpURLConnection conn = null;
    try {
        String urlStr = endpoint;
        if (!urlStr.contains("?")) urlStr = urlStr + "?k=";
        else if (!urlStr.endsWith("=")) urlStr = urlStr + "&k=";

        URL url = new URL(urlStr);
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

        String body = "{\"image\":\"" + b64 + "\"}";
        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();

        String resp = new String(bo.toByteArray(), "UTF-8");
        if (code != 200) return "ERR " + code + " " + resp;
        JSONObject j = new JSONObject(resp);
        if (!j.optBoolean("ok")) return "ERR proxy: " + resp;
        return j.optString("url");
    } catch (Throwable t) {
        return "ERR " + t.toString();
    } finally {
        try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) { }
    }
}

String[] recentImages(int limit) {
    String[] dirs = new String[]{
            "/sdcard/DCIM/Camera",
            "/sdcard/Pictures",
            "/sdcard/Download",
            "/sdcard/DCIM/Screenshots",
            "/sdcard/Pictures/Screenshots"
    };
    java.util.ArrayList list = new java.util.ArrayList();
    for (int i = 0; i < dirs.length; i++) {
        try {
            File d = new File(dirs[i]);
            if (!d.exists() || !d.isDirectory()) continue;
            File[] fs = d.listFiles();
            if (fs == null) continue;
            for (int k = 0; k < fs.length; k++) {
                String nm = fs[k].getName().toLowerCase();
                if (!fs[k].isFile()) continue;
                if (nm.endsWith(".png") || nm.endsWith(".jpg") || nm.endsWith(".jpeg")
                        || nm.endsWith(".webp") || nm.endsWith(".gif")) {
                    list.add(fs[k]);
                }
            }
        } catch (Throwable ignored) { }
    }
    java.util.Collections.sort(list, new java.util.Comparator() {
        public int compare(Object a, Object b) {
            File fa = (File) a, fb = (File) b;
            long d = fb.lastModified() - fa.lastModified();
            return d > 0 ? 1 : (d < 0 ? -1 : 0);
        }
    });
    int size = list.size() < limit ? list.size() : limit;
    String[] out = new String[size];
    for (int i = 0; i < size; i++) out[i] = ((File) list.get(i)).getAbsolutePath();
    return out;
}

void showUploadResult(final Activity act, final String url) {
    final Dialog dialog = new Dialog(act);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout box = new LinearLayout(act);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setBackground(hRound(Color.WHITE, 18, act));
    box.setPadding(hdp(act, 18), hdp(act, 18), hdp(act, 18), hdp(act, 14));

    TextView t = new TextView(act);
    t.setText(url.startsWith("ERR") ? "上传失败" : "上传成功，直链已复制");
    t.setTextSize(16);
    t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    t.setTextColor(Color.parseColor("#1C1B1F"));
    box.addView(t);

    TextView link = new TextView(act);
    link.setText(url);
    link.setTextSize(13);
    link.setTextIsSelectable(true);
    link.setTextColor(url.startsWith("ERR") ? Color.parseColor("#D93025") : Color.parseColor("#1A73E8"));
    link.setPadding(0, hdp(act, 10), 0, hdp(act, 10));
    box.addView(link);

    Button cp = new Button(act);
    cp.setText("再复制一次");
    cp.setTextSize(14);
    cp.setTextColor(Color.WHITE);
    cp.setBackground(hRound(Color.parseColor("#3B71FE"), 18, act));
    cp.setStateListAnimator(null);
    box.addView(cp);
    cp.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            hCopy(act, url);
            qqToast(2, "已复制");
        }
    });

    dialog.setContentView(box);
    dialog.setCanceledOnTouchOutside(true);
    Window w = dialog.getWindow();
    if (w != null) {
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.setDimAmount(0.45f);
    }
    dialog.show();
    if (w != null) w.setLayout(hdp(act, 320), ViewGroup.LayoutParams.WRAP_CONTENT);

    if (!url.startsWith("ERR")) hCopy(act, url);
}


void updatePreview(final ImageView iv, final TextView info, final String path) {
    try {
        if (path == null || path.trim().length() == 0) {
            iv.setImageDrawable(null);
            info.setText("未选择图片");
            return;
        }
        File f = new File(path.trim());
        if (!f.exists() || !f.isFile()) {
            iv.setImageDrawable(null);
            info.setText("文件不存在: " + path);
            return;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (o.outWidth <= 0) {
            iv.setImageDrawable(null);
            info.setText("不是图片: " + f.getName());
            return;
        }
        int sample = 1;
        while (o.outWidth / sample > 360 || o.outHeight / sample > 360) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        iv.setImageBitmap(bmp);
        long kb = f.length() / 1024;
        info.setText(f.getName() + "  ·  " + o.outWidth + "×" + o.outHeight + "  ·  " + kb + " KB");
    } catch (Throwable t) {
        info.setText("预览失败: " + t.getMessage());
    }
}

void showPicker(final Activity act, final EditText etPath, final ImageView iv, final TextView info) {
    final String[] files = recentImages(20);
    if (files.length == 0) {
        qqToast(0, "没找到图片");
        return;
    }
    String[] names = new String[files.length];
    for (int i = 0; i < files.length; i++) {
        String p = files[i];
        String[] seg = p.split("/");
        names[i] = seg.length > 2 ? seg[seg.length - 2] + "/" + seg[seg.length - 1] : p;
    }

    new android.app.AlertDialog.Builder(act)
            .setTitle("选一张图")
            .setItems(names, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface d, int which) {
                    etPath.setText(files[which]);
                    updatePreview(iv, info, files[which]);
                    d.dismiss();
                }
            })
            .setNegativeButton("取消", null)
            .show();
}

void showUploadPanel(final Activity act) {
    final Dialog dialog = new Dialog(act);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    ScrollView sv = new ScrollView(act);
    LinearLayout box = new LinearLayout(act);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setBackground(hRound(Color.WHITE, 20, act));
    box.setPadding(hdp(act, 20), hdp(act, 20), hdp(act, 20), hdp(act, 16));

    TextView title = new TextView(act);
    title.setText("上传图床");
    title.setTextSize(18);
    title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    title.setTextColor(Color.parseColor("#1C1B1F"));
    title.setGravity(android.view.Gravity.CENTER);
    box.addView(title);

    TextView lab1 = new TextView(act);
    lab1.setText("图片路径");
    lab1.setTextSize(13);
    lab1.setTextColor(Color.parseColor("#1C1B1F"));
    lab1.setPadding(0, hdp(act, 12), 0, hdp(act, 5));
    box.addView(lab1);

    final EditText etPath = new EditText(act);
    etPath.setHint("/sdcard/DCIM/Camera/xxx.jpg");
    etPath.setTextSize(14);
    etPath.setBackground(hRound(Color.parseColor("#F5F7FA"), 10, act));
    etPath.setPadding(hdp(act, 12), hdp(act, 9), hdp(act, 12), hdp(act, 9));
    box.addView(etPath);

    final ImageView iv = new ImageView(act);
    iv.setAdjustViewBounds(true);
    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
    iv.setBackgroundColor(Color.parseColor("#F5F7FA"));
    LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, hdp(act, 150));
    ilp.topMargin = hdp(act, 10);
    box.addView(iv, ilp);

    final TextView info = new TextView(act);
    info.setText("未选择图片");
    info.setTextSize(12);
    info.setTextColor(Color.parseColor("#49454F"));
    info.setPadding(0, hdp(act, 6), 0, 0);
    box.addView(info);

    Button pick = new Button(act);
    pick.setText("选图");
    pick.setTextSize(14);
    pick.setTextColor(Color.parseColor("#3B71FE"));
    pick.setBackground(hRound(Color.parseColor("#EEF2FF"), 16, act));
    pick.setStateListAnimator(null);
    LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, hdp(act, 40));
    plp.topMargin = hdp(act, 8);
    box.addView(pick, plp);
    pick.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            showPicker(act, etPath, iv, info);
        }
    });

    TextView lab2 = new TextView(act);
    lab2.setText("API Key（imgbb），或填代理地址 http…");
    lab2.setTextSize(13);
    lab2.setTextColor(Color.parseColor("#1C1B1F"));
    lab2.setPadding(0, hdp(act, 14), 0, hdp(act, 5));
    box.addView(lab2);

    final EditText etKey = new EditText(act);
    etKey.setText(apiKey());
    etKey.setTextSize(14);
    etKey.setBackground(hRound(Color.parseColor("#F5F7FA"), 10, act));
    etKey.setPadding(hdp(act, 12), hdp(act, 9), hdp(act, 12), hdp(act, 9));
    box.addView(etKey);

    final TextView status = new TextView(act);
    status.setTextSize(13);
    status.setTextColor(Color.parseColor("#49454F"));
    status.setPadding(0, hdp(act, 12), 0, 0);
    box.addView(status);

    final Button up = new Button(act);
    up.setText("上传");
    up.setTextSize(15);
    up.setTextColor(Color.WHITE);
    up.setBackground(hRound(Color.parseColor("#3B71FE"), 20, act));
    up.setStateListAnimator(null);
    LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, hdp(act, 46));
    ulp.topMargin = hdp(act, 14);
    box.addView(up, ulp);

    up.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            final String path = etPath.getText().toString().trim();
            final String key = etKey.getText().toString().trim();
            if (path.length() == 0) {
                qqToast(0, "先选一张图");
                return;
            }
            if (key.length() == 0) {
                qqToast(0, "API Key 不能为空");
                return;
            }
            putString(CFG, "key", key);
            File f = new File(path);
            if (!f.exists()) {
                qqToast(0, "文件不存在");
                return;
            }
            updatePreview(iv, info, path);
            status.setText("处理中…");
            up.setEnabled(false);
            new Thread(new Runnable() {
                public void run() {
                    final String b64 = shrinkToBase64(path, 512);
                    if (b64 == null) {
                        act.runOnUiThread(new Runnable() {
                            public void run() {
                                status.setText("读取/压缩失败，可能不是图片");
                                up.setEnabled(true);
                            }
                        });
                        return;
                    }
                    act.runOnUiThread(new Runnable() {
                        public void run() { status.setText("压缩完成，上传中…"); }
                    });
                    final String res = key.startsWith("http")
                            ? uploadToProxy(key, b64)
                            : uploadBase64(key, b64);
                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            up.setEnabled(true);
                            status.setText(res.startsWith("ERR") ? "失败" : "完成");
                            try {
                                if (dialog.isShowing()) dialog.dismiss();
                            } catch (Throwable ignored) { }
                            showUploadResult(act, res);
                        }
                    });
                }
            }).start();
        }
    });

    sv.addView(box);
    dialog.setContentView(sv);
    dialog.setCanceledOnTouchOutside(true);
    Window w = dialog.getWindow();
    if (w != null) {
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.setDimAmount(0.45f);
    }
    dialog.show();
    if (w != null) w.setLayout(hdp(act, 330), ViewGroup.LayoutParams.WRAP_CONTENT);
}

addItem("上传图床", "onImageHost");

void onImageHost(final int chatType, final String peerUin, final String peerName) {
    final Activity act = getNowActivity();
    if (act == null) {
        qqToast(1, "没拿到当前界面");
        return;
    }
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                showUploadPanel(act);
            } catch (Throwable t) {
                qqToast(1, "打开失败: " + t.toString());
            }
        }
    });
}
