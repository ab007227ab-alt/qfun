import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

loadJava(pluginPath + "/ShortcutApi.java");

final String CFG = "form";

int sdp(Context c, float dp) {
    if (c == null || c.getResources() == null) return (int) (dp * 2 + 0.5f);
    return (int) (dp * c.getResources().getDisplayMetrics().density + 0.5f);
}

GradientDrawable sRound(int color, int r, Context c) {
    GradientDrawable g = new GradientDrawable();
    g.setColor(color);
    g.setCornerRadius(sdp(c, r));
    return g;
}

EditText sField(Context ctx, LinearLayout parent, String label, String def,
                int inputType, String hint) {
    TextView lab = new TextView(ctx);
    lab.setText(label);
    lab.setTextSize(13);
    lab.setTextColor(Color.parseColor("#1C1B1F"));
    lab.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    lab.setPadding(sdp(ctx, 2), sdp(ctx, 10), 0, sdp(ctx, 5));
    parent.addView(lab);

    EditText et = new EditText(ctx);
    et.setText(def);
    et.setHint(hint);
    et.setHintTextColor(Color.parseColor("#A0A3BD"));
    et.setTextSize(14);
    et.setTextColor(Color.parseColor("#1C1B1F"));
    et.setInputType(inputType);
    et.setBackground(sRound(Color.parseColor("#F5F7FA"), 10, ctx));
    et.setPadding(sdp(ctx, 12), sdp(ctx, 9), sdp(ctx, 12), sdp(ctx, 9));
    parent.addView(et);
    return et;
}

void showShortcutForm(final Activity act, final String peer) {
    final Dialog dialog = new Dialog(act);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    ScrollView sv = new ScrollView(act);
    LinearLayout box = new LinearLayout(act);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setBackground(sRound(Color.WHITE, 20, act));
    box.setPadding(sdp(act, 20), sdp(act, 20), sdp(act, 20), sdp(act, 16));

    TextView title = new TextView(act);
    title.setText("群快捷栏");
    title.setTextSize(18);
    title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    title.setTextColor(Color.parseColor("#1C1B1F"));
    title.setGravity(android.view.Gravity.CENTER);
    box.addView(title);

    String lastGroup = getString(CFG, "group", peer == null ? "" : peer.replaceAll("[^0-9]", ""));
    final EditText etGroup = sField(act, box, "群号", lastGroup,
            InputType.TYPE_CLASS_NUMBER, "群号");
    final EditText etTitle = sField(act, box, "按钮名称",
            getString(CFG, "title", "惊喜"), InputType.TYPE_CLASS_TEXT, "快捷栏文字");
    final EditText etIcon = sField(act, box, "图标链接",
            getString(CFG, "icon", "https://q.qlogo.cn/g?b=qq&nk=10001&s=100"),
            InputType.TYPE_CLASS_TEXT, "https 图片直链");
    final EditText etJump = sField(act, box, "跳转链接",
            getString(CFG, "jump", "mqqapi://zplan/toast?msg=晚上好"),
            InputType.TYPE_CLASS_TEXT, "mqqapi:// 或 https://");
    final EditText etDesc = sField(act, box, "描述(可空)",
            getString(CFG, "desc", ""), InputType.TYPE_CLASS_TEXT, "");
    final EditText etAppId = sField(act, box, "AppID(留空=新增)",
            getString(CFG, "appid", ""), InputType.TYPE_CLASS_TEXT, "");

    Button quick = new Button(act);
    quick.setText("填 toast（普通）");
    quick.setTextSize(13);
    quick.setTextColor(Color.parseColor("#3B71FE"));
    quick.setBackground(sRound(Color.parseColor("#EEF2FF"), 16, act));
    quick.setStateListAnimator(null);
    LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, sdp(act, 40));
    qlp.topMargin = sdp(act, 12);
    box.addView(quick, qlp);
    quick.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            etJump.setText("mqqapi://zplan/toast?msg=" + etTitle.getText().toString().trim());
        }
    });

    Button quick2 = new Button(act);
    quick2.setText("填 toast（mode=1）");
    quick2.setTextSize(13);
    quick2.setTextColor(Color.parseColor("#3B71FE"));
    quick2.setBackground(sRound(Color.parseColor("#EEF2FF"), 16, act));
    quick2.setStateListAnimator(null);
    LinearLayout.LayoutParams q2lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, sdp(act, 40));
    q2lp.topMargin = sdp(act, 8);
    box.addView(quick2, q2lp);
    quick2.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            etJump.setText("mqqapi://zplan/toast?mode=1&msg=" + etTitle.getText().toString().trim());
        }
    });

    Button save = new Button(act);
    save.setText("保存并生效");
    save.setTextSize(15);
    save.setTextColor(Color.WHITE);
    save.setBackground(sRound(Color.parseColor("#3B71FE"), 20, act));
    save.setStateListAnimator(null);
    LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, sdp(act, 46));
    slp.topMargin = sdp(act, 16);
    box.addView(save, slp);

    save.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String gs = etGroup.getText().toString().trim().replaceAll("[^0-9]", "");
            String name = etTitle.getText().toString().trim();
            String icon = etIcon.getText().toString().trim();
            String jump = etJump.getText().toString().trim();
            String desc = etDesc.getText().toString().trim();
            String appId = etAppId.getText().toString().trim();

            if (gs.length() == 0 || name.length() == 0 || icon.length() == 0 || jump.length() == 0) {
                qqToast(0, "群号/名称/图标/跳转必填");
                return;
            }
            putString(CFG, "group", gs);
            putString(CFG, "title", name);
            putString(CFG, "icon", icon);
            putString(CFG, "jump", jump);
            putString(CFG, "desc", desc);
            putString(CFG, "appid", appId);

            final long group = Long.parseLong(gs);
            final String fAppId = appId.length() == 0
                    ? String.valueOf(System.currentTimeMillis()) + (int) (Math.random() * 900 + 100)
                    : appId;
            final String fName = name, fIcon = icon, fJump = jump, fDesc = desc;

            qqToast(2, "提交中…");
            ShortcutApi.query(group, new DumpRecv() {
                public void onReceive(byte[] data) {
                    JSONArray list = data == null ? new JSONArray() : ShortcutApi.itemsOf(data);
                    try {
                        JSONObject item = new JSONObject();
                        item.put("1", fAppId);
                        item.put("3", 6);
                        item.put("4", fName);
                        item.put("5", fIcon);
                        item.put("6", fDesc);
                        item.put("7", fJump);

                        boolean updated = false;
                        for (int i = 0; i < list.length(); i++) {
                            JSONObject it = list.optJSONObject(i);
                            if (it != null && fAppId.equals(it.optString("1"))) {
                                list.put(i, item);
                                updated = true;
                                break;
                            }
                        }
                        if (!updated) list.put(item);

                        ShortcutApi.save(group, list, new DumpRecv() {
                            public void onReceive(byte[] res) {
                                if (res == null) {
                                    qqToast(1, "保存失败：无回包");
                                    return;
                                }
                                ShortcutApi.refresh(group);
                                qqToast(2, "已保存，快捷栏刷新中");
                                try {
                                    Activity a = getNowActivity();
                                    if (a != null) a.runOnUiThread(new Runnable() {
                                        public void run() {
                                            try { if (dialog.isShowing()) dialog.dismiss(); }
                                            catch (Throwable ignored) { }
                                        }
                                    });
                                } catch (Throwable ignored) { }
                            }
                        });
                    } catch (Throwable t) {
                        qqToast(1, "组装失败: " + t.toString());
                    }
                }
            });
        }
    });

    sv.addView(box);
    dialog.setContentView(sv);
    dialog.setCanceledOnTouchOutside(true);
    Window win = dialog.getWindow();
    if (win != null) {
        win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        win.setDimAmount(0.45f);
    }
    dialog.show();
    if (win != null) {
        win.setLayout(sdp(act, 340), ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}

addItem("群快捷栏", "onShortcutMenu");

void onShortcutMenu(final int chatType, final String peerUin, final String peerName) {
    final Activity act = getNowActivity();
    if (act == null) {
        qqToast(1, "没拿到当前界面");
        return;
    }
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                showShortcutForm(act, peerUin);
            } catch (Throwable t) {
                qqToast(1, "打开失败: " + t.toString());
            }
        }
    });
}
