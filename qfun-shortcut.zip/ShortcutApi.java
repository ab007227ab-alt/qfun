import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.mobileqq.qroute.QRoute;
import com.tencent.mobileqq.troop.shortcut.api.ITroopShortcutApi;

loadJava(pluginPath + "/DumpRecv.java");
loadJava(pluginPath + "/DumpProto.java");
loadJava(pluginPath + "/DumpNet.java");

public class ShortcutApi {

    public static String clientVer() {
        try {
            String v = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0).versionName;
            if (v != null && v.length() > 0) return "android " + v;
        } catch (Throwable ignored) { }
        return "";
    }

    public static JSONArray itemsOf(byte[] data) {
        JSONArray arr = new JSONArray();
        try {
            DumpProto rp = new DumpProto();
            rp.fromBytes(data);
            JSONObject body = rp.toJSON().optJSONObject("4");
            if (body == null) return arr;
            Object o = body.opt("1");
            if (o instanceof JSONArray) return (JSONArray) o;
            if (o instanceof JSONObject) arr.put(o);
        } catch (Throwable ignored) { }
        return arr;
    }

    public static void query(long group, DumpRecv cb) {
        try {
            JSONObject body = new JSONObject();
            body.put("1", group);
            body.put("2", 30003);
            body.put("3", 2);

            JSONObject req = new JSONObject();
            req.put("1", 38665);
            req.put("2", 0);
            req.put("3", 0);
            req.put("4", body);
            req.put("6", clientVer());

            DumpProto proto = new DumpProto();
            proto.fromJSON(req);
            DumpNet.sendRequest("OidbSvcTrpcTcp.0x9709_0", proto.toBytes(), cb);
        } catch (Throwable t) {
            if (cb != null) cb.onReceive(null);
        }
    }

    public static void save(long group, JSONArray items, DumpRecv cb) {
        try {
            JSONObject body = new JSONObject();
            body.put("1", group);
            body.put("2", items);
            body.put("3", 1);

            JSONObject req = new JSONObject();
            req.put("1", 38668);
            req.put("2", 0);
            req.put("3", 0);
            req.put("4", body);
            req.put("6", clientVer());

            DumpProto proto = new DumpProto();
            proto.fromJSON(req);
            DumpNet.sendRequest("OidbSvcTrpcTcp.0x970c_0", proto.toBytes(), cb);
        } catch (Throwable t) {
            if (cb != null) cb.onReceive(null);
        }
    }

    public static void refresh(long group) {
        try {
            QRoute.api(ITroopShortcutApi.class).onShortcutChangePush(group);
        } catch (Throwable ignored) { }
    }
}
